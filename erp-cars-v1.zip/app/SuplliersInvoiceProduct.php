<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuplliersInvoiceProduct extends Model
{
    //
}
