@extends('layouts.app')

@section('pageTitle')
الرئسية
@endsection
@section('content')
   <div class="row">
       <h5>الرئسية</h5>
   </div>
@endsection
