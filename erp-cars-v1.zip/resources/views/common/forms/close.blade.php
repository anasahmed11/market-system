<button type="button" class="btn btn-default waves-effect" data-dismiss="modal">{{ $label }}</button>
