<button type="submit" class="btn btn-success waves-effect waves-light">{{ $label }}</button>
