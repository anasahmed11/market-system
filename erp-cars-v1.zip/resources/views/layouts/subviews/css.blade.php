<!-- Bootstrap Core CSS -->
<link href="{{ Request::root() }}/backend/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="{{ Request::root() }}/backend/assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="{{ Request::root() }}/backend/css/style.css" rel="stylesheet">
<link href="{{ Request::root() }}/backend/css/rtl.css" rel="stylesheet">
<!-- You can change the theme colors from here -->
<link href="{{ Request::root() }}/backend/css/colors/default-dark.css" id="theme" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
