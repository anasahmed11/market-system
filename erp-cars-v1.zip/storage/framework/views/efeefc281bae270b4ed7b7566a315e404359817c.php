<div class="form-group">
    <label for="<?php echo e($name); ?>" class="control-label"><?php echo e($label); ?>:</label>
    <textarea class="form-control"
                <?php if(isset($edit)): ?>
                id="<?php echo e($name); ?>-edit"
                <?php else: ?>
                id="<?php echo e($name); ?>"
                <?php endif; ?>
                name="<?php echo e($name); ?>"
                <?php if(isset($attrs)): ?>
                <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($attr['name']); ?> = "<?php echo e($attr['value']); ?>"
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                cols="30"
                rows="3">
    <?php if(isset($value)): ?>
        <?php echo e($value); ?>

    <?php endif; ?>
    </textarea>
</div>
