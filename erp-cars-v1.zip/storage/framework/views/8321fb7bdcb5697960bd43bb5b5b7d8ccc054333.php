<table class="table color-table inverse-table table-responsive">
    <?php echo e($data->appends(['sort' => 'votes'])->links()); ?>


    <thead>
    <tr>
        <th>#</th>
        <th>النوع</th>
        <th>الصنف</th>
        <th>التحكم</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->id); ?></td>
                <td>
                    <?php if($row->parent): ?>
                        <?php if(isset($row->rowParent->name)): ?>
                            <?php echo e($row->rowParent->name); ?>

                        <?php endif; ?>
                    <?php else: ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($row->name); ?></td>
                <td>
                    <button url="<?php echo e(route('categories.edit', $row->id)); ?>" parent="<?php if($row->parent): ?><?php echo e(0); ?><?php else: ?><?php echo e(1); ?><?php endif; ?>" type-url="<?php echo e(route('categories.types.edit', $row->id)); ?>" class="edit btn btn-warning">تعديل</button>
                    
                        
                        
                        
                    
                </td>
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="text-center">
    <?php echo e($data->links()); ?>

</div>
