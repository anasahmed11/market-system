<?php $__env->startSection('pageTitle'); ?>
الرئسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row">
       <h5>الرئسية</h5>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>