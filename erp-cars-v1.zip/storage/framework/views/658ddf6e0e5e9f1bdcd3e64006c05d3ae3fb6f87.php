<div class="form-group">
    <label for="<?php echo e($name); ?>" class="control-label">نوع الدين:</label>
    <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="select2">
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($option->$value); ?>"><?php echo e($option->$label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
