<div class="form-group">
    <label for="debt" class="control-label">نوع الدين:</label>
    <select name="debt" id="debt" class="select2">
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($option->$value); ?>"><?php echo e($option->$label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
