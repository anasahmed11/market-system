<?php $__env->startSection('pageTitle'); ?>
    الاصناف
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row text-center">
        <div class="col-md-6 text-left">
         <?php echo $__env->make('common.forms.search', [
            'searchLabel' => 'بحث',
            'route' => route('categories.search'),
            'types' => $searchTypes
         ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-6">
            <button class="add-new btn btn-success" data-toggle="modal" data-target="#add-new" parent="0">صنف جديد</button>
            <button class="add-new btn btn-primary" data-toggle="modal" data-target="#add-new" parent="1">نوع جديد</button>
        </div>
    </div>
    <br>
    <div id="main-table" class="row">
        <?php echo $table; ?>

    </div>

    <?php echo $__env->make('backend.categories.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section id="edit"></section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_js'); ?>
    <?php echo $__env->make('backend.categories.ajax', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>