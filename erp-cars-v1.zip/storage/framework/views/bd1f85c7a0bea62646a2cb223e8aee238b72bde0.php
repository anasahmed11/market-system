<div id="add-debts"
     class="modal fade"
     tabindex="-1"
     role="dialog"
     aria-labelledby="اضافة دين"
     aria-hidden="true"
     style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">اضافة</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <form id="form-add-debts" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="debt-types"></div>
                    <?php echo $__env->make('common.forms.input', ['label'=> 'القيمة', 'name'=> 'value', 'type'=> 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.textarea', ['label'=> 'الوصف', 'name'=> 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.input', ['label'=> 'التاريخ', 'name'=> 'date', 'type'=> 'date'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="modal-footer">
                    <?php echo $__env->make('common.forms.close', ['label'=> 'الغاء'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.submit', ['label'=> 'حفظ'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </form>
        </div>
    </div>
</div>

