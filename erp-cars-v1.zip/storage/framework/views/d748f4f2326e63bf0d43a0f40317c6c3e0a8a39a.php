<div class="table-responsive">
    <table class="table color-table inverse-table">
    <?php echo e($data->appends(['sort' => 'votes'])->links()); ?>


    <thead>
    <tr>
        <th>#</th>
        <th>الاسم الاول</th>
        <th>الاسم الاخير</th>
        <th>اسم الشهرة</th>
        <th>رقم الموبيل</th>
        <th>العنوان</th>
        <th>اجمالي المديونية</th>
        <th>التحكم</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($supplier->id); ?></td>
            <td><?php echo e($supplier->f_name); ?></td>
            <td><?php echo e($supplier->l_name); ?></td>
            <td><?php echo e($supplier->nickname); ?></td>
            <td><?php echo e($supplier->phone); ?></td>
            <td><?php echo e($supplier->location); ?></td>
            <td><?php echo e($supplier->total_indebtedness); ?></td>
            <td>
                <?php if($supplier->total_indebtedness): ?>
                    <button url="<?php echo e(route('suppliers_debts.types.remove', $supplier->id)); ?>"
                            class="btn btn-primary btn-remove-debt"
                            data-toggle="modal"
                            data-target="#remove-debts">
                        تسديد قسط
                    </button>
                <?php endif; ?>
                <button  url="<?php echo e(route('suppliers_debts.types.add', $supplier->id)); ?>"
                         class="btn btn-info btn-add-debt"
                         data-toggle="modal"
                         data-target="#add-debts">اضافة دين
                </button>
                <a href="" class="btn btn-dribbble">الفواتير</a>
                <button url="<?php echo e(route('suppliers.edit', $supplier->id)); ?>" class="edit btn btn-warning">تعديل</button>
                <form action="<?php echo e(route('suppliers.destroy', $supplier->id)); ?>" class="delete-one d-inline-block" method="post" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<div class="text-center">
    <?php echo e($data->links()); ?>

</div>
