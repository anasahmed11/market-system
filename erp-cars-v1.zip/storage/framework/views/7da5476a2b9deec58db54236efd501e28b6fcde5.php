<?php $__env->startSection('pageTitle'); ?>
    مديونية <span class="font-bold"><a href="<?php echo e(route('customers.show', $customer)); ?>"><?php echo e($customer->f_name); ?></a></span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row text-center">
        <div class="col-md-12">
            <button class="btn btn-success" data-toggle="modal" data-target="#add-new"> جديد</button>
        </div>
    </div>
    <br>
    <div class="row">
        <?php echo $table; ?>

    </div>

    <?php echo $__env->make('backend.customers.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>