<?php if(!isset($group)): ?>
    <div class="form-group">
        <label for="<?php echo e($name); ?>" class="control-label"><?php echo e($input_label); ?>:</label>
        <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($object)): ?>
                    <option value="<?php echo e($option->$value); ?>" selected><?php echo e($option->$label); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($option->$value); ?>"><?php echo e($option->$label); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
<?php elseif($group): ?>
    <div class="form-group">
        <label for="<?php echo e($name); ?>" class="control-label"><?php echo e($input_label); ?>:</label>
        <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <optgroup label="<?php echo e($option->name); ?>">
                    <?php $__currentLoopData = $option->rowChilds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($object)): ?>
                            <option value="<?php echo e($sub->$value); ?>" selected><?php echo e($sub->$label); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($sub->$value); ?>"><?php echo e($sub->$label); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
<?php endif; ?>
