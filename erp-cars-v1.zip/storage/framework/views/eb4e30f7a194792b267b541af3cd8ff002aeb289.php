<form action="<?php echo e($route); ?>" method="post" class="form-search row">
    <?php echo csrf_field(); ?>
    <div class="col-md-2">
        <label> <?php echo e($searchLabel); ?> </label>
    </div>
    <div class="col-md-5">
        <select name="search_type" class="form-control">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=> $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-5">
        <input type="text" name="search" class="input-search form-control">
    </div>
</form>
