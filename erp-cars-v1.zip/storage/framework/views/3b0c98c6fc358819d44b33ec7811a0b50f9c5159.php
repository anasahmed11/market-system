<div id="edit-one"
     class="modal fade"
     tabindex="-1"
     role="dialog"
     aria-labelledby="تعديل العملاء"
     aria-hidden="true"
     style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">تعديل</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <form method="post" action="<?php echo e(route('products.update', $object->id)); ?>" class="form-edit">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                   <div id="types-edit"></div>
                    <?php echo $__env->make('common.forms.input', ['edit'=> true, 'value'=> $object->name, 'name'=> 'name', 'label'=> 'الاسم'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.textarea', ['edit'=> true, 'value'=> $object->name,'name'=> 'description', 'label'=> 'التفاصيل'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>      </div>
                <div class="modal-footer">
                    <?php echo $__env->make('common.forms.close', ['label'=> 'الغاء'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.submit', ['label'=> 'حفظ'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </form>
        </div>
    </div>
</div>

