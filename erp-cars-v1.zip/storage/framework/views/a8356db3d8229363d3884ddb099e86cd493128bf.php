<div class="table-responsive">
    <table class="table color-table inverse-table">
    <thead>
    <tr>
        <th>#</th>
        <th>الاسم</th>
        <th>البريد</th>
        <th>رقم الموبيل</th>
        <th>مدير</th>
        <th>التحكم</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->phone); ?></td>
        <td>
            <?php if($user->is_admin): ?>
                <span class="btn btn-success">نعم</span>
            <?php else: ?>
                <span class="btn btn-danger">لا</span>
            <?php endif; ?>
        </td>
        <td>
            <a href="" class="btn btn-warning">تعديل</a>
            <a href="" class="btn btn-danger">حذف</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<div class="text-center">
    <?php echo e($data->links()); ?>

</div>
