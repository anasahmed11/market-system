<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Tell the browser to be responsive to screen width -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Ahmed Elnemr">
        <!-- Favicon icon -->
        <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
        <title>ERP | <?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->yieldContent('before_css'); ?>
        <?php echo $__env->make('layouts.subviews.css', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('after_css'); ?>
    </head>

    <body class="fix-header card-no-border fix-sidebar">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Admin Pro</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                <b>
                    LOGO
                </b>
            </a>
            <button class="navbar-toggler"
                    type="button" data-toggle="collapse"
                    data-target="#main-nav" aria-controls="main-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="main-nav">
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav mr-auto" >
                    <!-- This is  -->
                    <li class="nav-item dropdown bg-success">
                        <a class="dropdown-toggle d-inline-block"
                           data-toggle="dropdown"
                           href="#"
                           style="height: 100%; line-height: 35px">
                            فاتورة بيع
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="bg-success">
                                <a class="nav-link btn btn-success" href="<?php echo e(route('invoices.create', 'selling-1')); ?>">
                                    قطاعي
                                </a>
                            </li>
                            <li class="bg-info">
                                <a class="nav-link btn btn-info" href="<?php echo e(route('invoices.create', 'selling-2')); ?>">
                                    جملة
                                </a>
                            </li>
                        </ul>

                    </li>
                    <li class="nav-item bg-info">
                        <a class="nav-link btn btn-info" href="<?php echo e(route('invoices.create', 'buying-1')); ?>">
                            <i class="ti-user" ></i>فاتورة شراء
                        </a>
                    </li>
                    <li class="nav-item btn-dribbble">
                        <a class="nav-link btn btn-dribbble" href="<?php echo e(route('products.index')); ?>">
                            <i class="ti-package"></i>المنتجات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('customers.index')); ?>">
                            <i class="ti-face-smile"></i>العملاء
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                            <i class="ti-user"></i>المستخدمين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('branches.index')); ?>">
                            <i class="ti-home"></i>الفروع
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('suppliers.index')); ?>">
                            <i class="ti-import"></i>الموردين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">
                            <i class="ti-import"></i>الاصناف
                        </a>
                    </li>
                </ul>
                <!-- ============================================================== -->
                <!-- User profile and search -->
                <!-- ============================================================== -->
                <ul class="navbar-nav my-lg-0">
                    
                    
                    
                    
                        
                        
                            
                                
                                    
                                        
                                        
                                            
                                            
                                    
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            
                        
                    
                </ul>
            </div>
        </nav>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header-tabs">
                                <h3 class="text-center m-t-10"><?php echo $__env->yieldContent('pageTitle'); ?></h3>
                                <hr style="width: 80%">
                            </div>
                            <div class="card-body">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer">
                © 2019 GitSolve
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <?php echo $__env->yieldContent('before_js'); ?>
    <?php echo $__env->make('layouts.subviews.js', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('after_js'); ?>

    </body>
</html>
