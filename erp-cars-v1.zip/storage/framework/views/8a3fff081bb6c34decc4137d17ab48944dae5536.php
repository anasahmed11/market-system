<div class="table-responsive">
    <table class="table color-table inverse-table">
    <thead>
    <tr>
        <th>#</th>
        <th>الاسم</th>
        <th>العنوان</th>
        <th>رقم الموبيل</th>
        <th>التحكم</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($branch->id); ?></td>
        <td><?php echo e($branch->name); ?></td>
        <td><?php echo e($branch->location); ?></td>
        <td><?php echo e($branch->phone); ?></td>
        <td>
            <button url="<?php echo e(route('branches.edit', $branch->id)); ?>" class="edit btn btn-warning">تعديل</button>
            <form action="<?php echo e(route('branches.destroy', $branch->id)); ?>" class="delete-one d-inline-block" method="post" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">حذف</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<div class="text-center">
    <?php echo e($data->links()); ?>

</div>
