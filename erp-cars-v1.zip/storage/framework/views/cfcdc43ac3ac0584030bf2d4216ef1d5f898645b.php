<button type="button" class="btn btn-default waves-effect" data-dismiss="modal"><?php echo e($label); ?></button>
