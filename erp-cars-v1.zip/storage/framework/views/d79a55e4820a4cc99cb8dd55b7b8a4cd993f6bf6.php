<button type="submit" class="btn btn-success waves-effect waves-light"><?php echo e($label); ?></button>
