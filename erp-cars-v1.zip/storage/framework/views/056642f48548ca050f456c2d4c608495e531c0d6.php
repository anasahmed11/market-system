<div id="add-new"
     class="modal fade"
     tabindex="-1"
     role="dialog"
     aria-labelledby="اضافة مستخدم"
     aria-hidden="true"
     style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">اضافة</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <form method="post" action="<?php echo e(route('products.store')); ?>" class="form-add">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="types"></div>
                    <?php echo $__env->make('common.forms.input', ['name'=> 'name', 'label'=> 'الاسم'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.input', ['name'=> 'price', 'label'=> 'سعر القطاعي', 'type'=> 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.input', ['name'=> 'price2', 'label'=> 'سعر الجملة', 'type'=> 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.input', ['name'=> 'reorder_point', 'label'=> 'نقطة الطلب', 'type'=> 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.input', ['name'=> 'quantity', 'label'=> 'الكمية', 'type'=> 'number'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.textarea', ['name'=> 'description', 'label'=> 'التفاصيل'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="modal-footer">
                    <?php echo $__env->make('common.forms.close', ['label'=> 'الغاء'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('common.forms.submit', ['label'=> 'حفظ'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </form>
        </div>
    </div>
</div>

